package com.example.game3;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
